/**
 * Yes
 */
$(document).ready(function () {
    $("#alert").newsTicker();
});