<?php

/**
 * Remplacez ici <ONESIGNAL_APP_ID> par la valeur du champ "ONESIGNAL APP ID" dans OneSignal
 */
define('ONESIGNAL_APP_ID',  '9d06a052-42ec-4e2e-8407-94dbb81b4766');

/**
 * Remplacez ici <REST_API_KEY> par la valeur du champ "REST API KEY" dans OneSignal
 */
define('ONESIGNAL_API_KEY', 'YzNiMzEwMzgtMGFjYy00ZTliLWFkYmYtZjlmODMxMWRhZDI2');